
<?php
include("connect.php");
$userid = $_GET['userid'];
$movieid=$_GET['movieid'];
$showingid=$_GET['showingid'];
$sql = "SELECT DISTINCT starttime,roomname,endtime,cinemaname,showingid,movieid,moviename,userid FROM movie NATURAL JOIN showing NATURAL 
JOIN ticket NATURAL JOIN screeningroom WHERE userid='$userid' and showingid='$showingid';";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // 输出数据
    while ($row = $result->fetch_assoc()) {
        $moviename= $row["moviename"];
        $showingid = $row["showingid"];
        $startime=$row['starttime'];
        $endtime=$row['endtime'];
        $cinemaname=$row['cinemaname'];
        $roomname=$row['roomname'];
    }
}
$conn->close();
?>

<!DOCTYPE html>
<html>

<head>
    <meta charset="UTF-8">
    <title>create your order </title>
    <style>
        body {
            background-color: #f2f2f2;
            font-family: Arial, sans-serif;
        }

        .login-container {
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            background-color: #fff;
            padding: 50px;
            border-radius: 10px;
            box-shadow: 0px 10px 50px rgba(0, 0, 0, 0.3);
            text-align: center;
            opacity: 0;
            animation: fade-in 0.5s forwards;
            width: 450px;
        }


        .login-container h1 {
            font-size: 36px;
            color: #333;
            text-align: center;
            margin-bottom: 30px;
        }

        .button-container {
            display: inline-block;
            margin-top: 20px;
        }

        .return-button {
            background-color: #705a70;
            color: white;
            border: none;
            padding: 10px 20px;
            width: 120px;
            text-align: center;
            text-decoration: none;
            display: inline-block;
            font-size: 16px;
            margin: 4px 2px;
            cursor: pointer;
            border-radius: 5px;
        }

        label {
            display: block;
            margin-bottom: 10px;
        }

        .form-row {
            display: flex;
            align-items: center;
            justify-content: center;
            margin-bottom: 10px;
        }

        .form-row label {
            flex: 0 0 auto;
            text-align: center;
            margin-right: 10px;
        }

        .button-row {
            display: flex;
            justify-content: center;
            margin-top: 20px;
        }

        .button-row input[type="submit"],
        .button-row button.return-button {
            margin: 0 5px;
        }

        input[type=text],
        select {
            width: 100%;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
            box-sizing: border-box;
            font-size: 16px;
        }

        form input[type="date"] {
            width: 100%;
            height: 40px;
            border: 1px solid #ccc;
            border-radius: 5px;
            box-sizing: border-box;
            font-size: 16px;
            font-family: Arial, sans-serif;
        }

        input[type=submit] {
            background-color: #705a70;
            width: 120px;
            color: #fff;
            border: none;
            padding: 10px 20px;
            border-radius: 5px;
            cursor: pointer;
            font-size: 16px;
            margin-top: 10px;
        }

        input[type=submit]:hover {
            background-color: #3e8e41;
        }

        .center {
            text-align: center;
        }

        @keyframes fade-in {
            0% {
                opacity: 0;
            }

            100% {
                opacity: 1;
            }
        }

        form label {
            margin-bottom: 10px;
        }

        .form-row select {
            width: 320px;
        }

        .form-row input {
            width: 320px;
        }

        form label,
        form input,
        form select {
            margin-bottom: 10px;
            text-align: center;
        }
    </style>
</head>

<body>
    <div class="login-container">
        <h1>create a  order</h1>
        <div class="center">
            <form method="post" action="upneworder.php">
     
                <input type="hidden" id="ticketid" name="ticketid" value="">
                <input type="hidden" id="userid" name="userid" value= "<?php echo $userid;?>">
                <div class="form-row">
                    <label for="moviename">movie name</label>
                    <input id="moviename" name="moviename" value="The Lord of the Rings: The Return of the King">
                </div>
                <div class="form-row">
                    <label for="cinemaname">cinema name</label>
                    <input id="cinemaname" name="cinemaname" value="Hype Cinema">
                </div>
                <div class="form-row">
                    <label for="showingid">screening ID</label>
                    <input id="showingid" name="showingid" value="<?php echo $showingid;?>">
                </div>
                <div class="form-row">

                    <label for="screeningroom">screeming room name</label>
                    <input type="text" id="screeningroom" name="screeningroom" value="BOOM BOOM ROOM">
                </div>
                <div class="form-row">

                    <label for="starttime">start time</label>
                    <input type="text" id="starttime" name="starttime" value="2024-05-17 07:34:29">
                </div>
                <div class="form-row">

                    <label for="endtime">end time</label>
                    <input type="text" id="endtime" name="endtime" value="2024-05-17 07:34:29">
                </div>
                <div class="form-row">

                    <label for="seatrow">seat row</label>

                    <select id="seatrow" name="seatrow" onchange="filterColumn();">
                        <option value="0">please choose the seat row...</option>
                        <?php
                        include("connect.php");

                        $sql = "SELECT DISTINCT seatrow,showingid  FROM showing natural join screeningroom natural join seat";
                        $result = $conn->query($sql);

                        if ($result->num_rows > 0) {
                            while ($row = $result->fetch_assoc()) {
                                echo "<option value='" . $row["seatrow"] . "' data-showingid='" . $row["showingid"] . "'>" . $row["seatrow"] . "</option>";
                            }
                        } else {
                            echo "<option value=''>can't find the seat!</option>";
                        }

                        $conn->close();
                        ?>
                    </select>

                    <script>
                        function filterRow() {
                            var showingid = document.getElementById("showingid").value;
                            var showing = document.querySelectorAll("#seatrow option");

                            for (var i = 0; i < showing.length; i++) {
                                if (showing[i].getAttribute("data-showingid") === showingid || showingid === "") {
                                    showing[i].style.display = "block";
                                } else {
                                    showing[i].style.display = "none";
                                }
                            }
                        }
                    </script>
                </div>
                <div class="form-row">

                    <label for="seatcolumn">seat column</label>

                    <select id="seatcolumn" name="seatcolumn">
                        <option value="0">please select the seat column...</option>
                        <?php
                        include("connect.php");
                        // 还要进行排的限定
                        $sql = "SELECT distinct seatcolumn,seatrow,showingid,status FROM showing NATURAL JOIN seat WHERE status ='not sold'";
                        $result = $conn->query($sql);

                        if ($result->num_rows > 0) {
                            while ($row = $result->fetch_assoc()) {
                                echo "<option value='" . $row["seatcolumn"] . "' data-showingid='" . $row["showingid"] . "' data-seatrow='" . $row["seatrow"] . "' data-status='" . $row["status"] . "'>" . $row["seatcolumn"] . "</option>";
                            }
                        } else {
                            echo "<option value=''>can't find the seat column!</option>";
                        }

                        $conn->close();
                        ?>
                    </select>

                    <script>
                        function filterColumn() {
                            var showingid = document.getElementById("showingid").value;
                            var seatrow = document.getElementById("seatrow").value;
                            var showing = document.querySelectorAll("#seatcolumn option");

                            for (var i = 0; i < showing.length; i++) {
                                var status = showing[i].getAttribute("data-status");
                                if (
                                    (showing[i].getAttribute("data-showingid") === showingid || showingid === "") &&
                                    status === "not sold" && showing[i].getAttribute("data-seatrow") === seatrow
                                ) {
                                    showing[i].style.display = "block";
                                } else {
                                    showing[i].style.display = "none";
                                }
                            }
                        }
                    </script>

                </div>

                <input type="submit" value="reserve">
            </form>
            <form>
                <button class="return-button">return</button>
            </form>
        </div>
    </div>
    </div>

</body>

</html>