<?php
$conn = mysqli_connect('localhost:3306', 'root', '');

//如果连接数据库失败就输出错误信息
if (!$conn) {
    die("error：" . mysqli_error($conn));
}

//选择数据库
mysqli_select_db($conn, 'exercise');

//选择字符集
mysqli_set_charset($conn, 'utf8');

// 获取POST请求中的数据并进行安全性验证
$username = mysqli_real_escape_string($conn, $_POST["username"]);
$password = mysqli_real_escape_string($conn, $_POST["password"]);
$repassword = mysqli_real_escape_string($conn, $_POST["repassword"]);

//判断两次密码是否一致
if ($password != $repassword) {
	echo "<script>alert(\"ERROR!\");</script>";
	echo "<script>url=\"register.html\";window.location.href=url;</script>";
	exit();
	;
}

//判断用户名是否已被注册
$sql = "select * from user where username = '$username'";
$result = mysqli_query($conn, $sql);
if (mysqli_num_rows($result) > 0) {
	echo "<script>alert(\"already existed!\");</script>";
	echo "<script>url=\"register.html\";window.location.href=url;</script>";
	exit();
}
else{

  $sql = "insert into user(UserName,Password,Phone,gender,motto,birthday) values('$username','$password',NULL,NULL,NULL,NULL)";
  $result = mysqli_query($conn, $sql);
if ($result) {
	echo "<script>alert(\"successfully regested,go to your homepage!\");</script>";
	echo "<script>url=\"login.html\";window.location.href=url;</script>";
} else {
	//数据库报错
	echo"<script>alert(\"error!\");</script>";
	die("Error: " . mysqli_error($conn));
}}

//关闭数据库
mysqli_close($conn);

?>