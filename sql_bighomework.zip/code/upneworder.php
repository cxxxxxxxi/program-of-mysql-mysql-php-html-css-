<?php
include("connect.php");

$ticketid = $_POST['ticketid'];
$showingid = $_POST['showingid'];
$seatrow = $_POST['seatrow'];
$seatcolumn = $_POST['seatcolumn'];
$userid = $_POST['userid'];
$roomid=$_POST['roomid'];

// 创建存储过程调用语句
$sql = "INSERT INTO ticket(ticketid, ShowingID, UserId, PurchaseTime, SEATID, TicketStatus) VALUES ('$ticketid','$showingid',
'$userid',(SELECT CURRENT_TIMESTAMP),'(SELECT Seatid FROM seat WHERE  SeatRow='$seatrow' and SeatColumn='$seatcolumn' and RoomID='$roomid)','get successfully!');";

// 执行存储过程
$result = $conn->query($sql);

// 获取存储过程的输出结果
$output = $conn->query("SELECT @result AS result")->fetch_assoc();
$p_result = $output['result'];

// 判断调用是否成功
if ($p_result == 'success') {
    echo "<script>alert('Order modification successful');</script>";
} else {
    echo "<script>alert('Order modification successfully!' + '{$p_result}');</script>";

}
echo "<script>window.location.href = 'myticket.php?userid=' + encodeURIComponent($userid);</script>";

$conn->close();
?>



