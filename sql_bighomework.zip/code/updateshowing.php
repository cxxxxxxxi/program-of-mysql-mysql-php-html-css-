<?php

//连接数据库

$conn = mysqli_connect('localhost:3306', 'root', '');

//如果连接数据库失败就输出错误信息
if (!$conn) {
    die("error：" . mysqli_error($conn));
}
mysqli_select_db($conn,'exercise');
mysqli_set_charset($conn,'utf8');

$showingid = $_POST['showingid'];
$movieid = $_POST['movieid'];
$roomid = $_POST['roomid'];
$seatsremained = $_POST['seatsremained'];
$price = $_POST['price'];
$starttime = $_POST['starttime'];
$endtime = $_POST['endtime'];

// 检查数据完整性a
if (empty($showingid) || empty($movieid) || empty($roomid) || empty($seatsremained) || empty($price) || empty($starttime) || empty($endtime)) {
    echo "<script>alert('please fill in all the blocks');</script>";
}

// 验证movieid和price为数字
if (!is_numeric($movieid) || !is_numeric($price)) {
    echo "<script>alert('movie's id and price must be digital!');</script>";
}

// 转换日期时间格式
$starttime = date('Y-m-d H:i:s', strtotime($starttime));
$endtime = date('Y-m-d H:i:s', strtotime($endtime));
if(!($endtime>$starttime)){
    echo "<script>alert(' error!end time must be later than start time!');</script>";
}
$sql = "INSERT INTO showing (showingid, movieid, roomid, seatsremained, price, starttime, endtime) 
        VALUES ('$showingid', '$movieid', '$roomid', '$seatsremained', '$price', '$starttime', '$endtime');
        ";


// 执行插入语句
try {
    // 执行插入语句
    if ($conn->query($sql) === TRUE) {
        echo "<script>alert('insert successfully！');</script>";
    } else {
        echo "<script>alert('error：" . $conn->error . "');</script>";
    }
} catch (mysqli_sql_exception $e) {
    echo "<script>alert('error：" . $e->getMessage() . "');</script>";
}

echo "<script>url = \"moviemanage.php?\"; window.location.href = url;</script>";

$conn->close();
?>