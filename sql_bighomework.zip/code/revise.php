<?php
// 建立数据库连接
include("connect.php");

// 开始事务
$conn->begin_transaction();

// 删除操作的SQL语句
$movieID = $_GET['movieid'];
$sql = "select * from movie where movieid = '$movieID' ";
#$sql=0;
$result = $conn->query($sql);
// 执行删除操作conn->query($sql)
if ($conn->query($sql)) {
    // 删除成功
    echo '<script>alert(" revise successfully!");</script>';
    $conn->commit(); // 提交事务
} else {
    // 删除失败
    echo '<script>alert("error!");</script>';
    $conn->rollback(); // 回滚事务
}

echo '<script>window.location.href = "moviemanage.php";</script>';
$conn->close();
?>