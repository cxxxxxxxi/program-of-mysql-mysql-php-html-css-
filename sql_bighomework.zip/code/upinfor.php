<?php
include("connect.php");

$userid = $_GET['userid'];
$gender = $_GET['gender'];
$age = $_GET['age'];

// 创建存储过程调用语句
$sql = "CALL Update_user_info(\"$userid\", \"$gender\",$age,  @result);";

// 执行存储过程
$result = $conn->query($sql);

// 获取存储过程的输出结果
$output = $conn->query("SELECT @result AS result")->fetch_assoc();
$p_result = $output['result'];

// 判断调用是否成功
if ($p_result == 'success') {
    echo "<script>alert('update successful');</script>";
} else {
    echo "<script>alert('error' + '{$p_result}');</script>";

}
echo "<script>window.location.href = 'myticket.php?userid=' + encodeURIComponent($userid);</script>";

$conn->close();
?>



