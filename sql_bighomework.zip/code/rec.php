<?php
session_start();
$name=$_POST['username'];
$_SESSION["uname"]=$name;
include("connect.php");
$sql = "select userid from user where username = '$username'";
$result = mysqli_query($conn, $sql);
//自动保存已登录用户
if (mysqli_num_rows($result) > 0) {
	echo "<script>alert(\"You have already logged in!\");</script>";
	echo "<script>url=\"register.html\";window.location.href=url;</script>";
	exit();
}


//关闭数据库
mysqli_close($conn);

?>