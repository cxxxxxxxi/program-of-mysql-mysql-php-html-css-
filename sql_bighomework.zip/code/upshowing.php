<?php
            // 连接数据库
            include("connect.php");

            // 查询电影信息
            $sql = "select showingid,movieid,moviename,cinemaid,cinemaname,roomid,roomname,showingid,starttime,endtime  
            from showing natural join movie natural join screeningroom natural join cinemas  where 1=1";
            if (isset($_GET['name'])) {
                $name = $_GET['name'];
                $sql .= " AND moviename LIKE '%$name%'";
            }
            $sql .= " order BY MovieID";
            $result = $conn->query($sql);

            // 输出表格
            if ($result->num_rows > 0) {
                while ($row = $result->fetch_assoc()) {
                    echo "<tr>";
                    echo "<td>" . $row["showingid"] . "</td>";
                    echo "<td>" . $row["movieid"] . "</td>";
                    echo "<td>" . $row["moviename"] . "</td>";
                    echo "<td>" . $row["cinemaid"] . "</td>";
                    echo "<td>" . $row["cinemaname"] . "</td>";
                    echo "<td>" . $row["roomid"] . "</td>";
                    echo "<td>" . $row["roomname"] . "</td>";
                    echo "<td>" . $row["starttime"] . "</td>";
                    echo "<td>" . $row["endtime"] . "</td>";
                    echo "</tr>";
                }
            }
            if (isset($_GET['name'])) {
                $name = $_GET['name'];
                $sql .= " AND m.MovieName LIKE '%$name%'";
            }

            // 断开数据库连接
            mysqli_close($conn);
            ?>