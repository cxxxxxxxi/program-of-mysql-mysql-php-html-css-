<?php
//连接数据库
include("connect.php");

$userid = $_GET["userid"];
$sql="select *from user WHERE userid='$userid'";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
  // 输出数据
  while ($row = $result->fetch_assoc()) {
    $username = $row["username"];
    $phone = $row["phone"];
    $birthday = $row["birthday"];
    $motto = $row["motto"];
    $gender = $row["gender"];
  }
  $birthday_str = date("Y-m-d", strtotime($birthday));
} else {
  echo "0 result";
}
$conn->close();
?>

<!DOCTYPE html>
<html>

<head>
  <meta charset="UTF-8">
  <title>self information</title>
  <style>
    body {
      background-color: #f2f2f2;
      font-family: Arial, sans-serif;
    }

    .login-container {
      position: absolute;
      top: 50%;
      left: 50%;
      transform: translate(-50%, -50%);
      background-color: #fff;
      padding: 50px;
      border-radius: 10px;
      box-shadow: 0px 10px 50px rgba(0, 0, 0, 0.3);
      text-align: center;
      opacity: 0;
      animation: fade-in 0.5s forwards;
      width: 250px;
    }


    .login-container h1 {
      font-size: 36px;
      color: #333;
      text-align: center;
      margin-bottom: 70px;
    }

    .button-container {
      display: inline-block;
      margin-top: 20px;
    }

    .return-button {
      background-color: #2097d7;

      color: white;
      border: none;
      padding: 10px 20px;
      width: 120px;
      text-align: center;
      text-decoration: none;
      display: inline-block;
      font-size: 16px;
      margin: 4px 2px;
      cursor: pointer;
      border-radius: 5px;
    }
    .return-button:hover {
      background-color: #EEA23A;
    }

  

    label {
      display: block;
      margin-bottom: 10px;
    }

    input[type=text],
    select {
      width: 100%;
      padding: 10px;
      border: 1px solid #ccc;
      border-radius: 5px;
      box-sizing: border-box;
      font-size: 16px;
    }

    form input[type="date"] {
      width: 100%;
      height: 40px;
      font-size: 16px;
      font-family: Arial, sans-serif;
      border: 1px solid #ccc;
      border-radius: 5px;
      box-sizing: border-box;
    }

    input[type=submit] {
      background-color: #2097d7;
      width: 120px;
      color: #fff;
      border: none;
      padding: 10px 20px;
      border-radius: 5px;
      cursor: pointer;
      font-size: 16px;
      margin-top: 10px;
    }

    input[type=submit]:hover {
      background-color: #EEA23A;
    }

    .center {
      text-align: center;
    }

    @keyframes fade-in {
      0% {
        opacity: 0;
      }

      100% {
        opacity: 1;
      }
    }

    form label {
      margin-bottom: 10px;
    }

    form label,
    form input,
    form select {
      margin-bottom: 10px;
      text-align: center;
    }
  </style>
</head>

<body>
  <div class="login-container">
    <h1>self information</h1>
    <div class="center">
      <form method="post" action="update.php">
        <input type="hidden" name="userid" value="<?php echo $userid; ?>">
        <label for="username">user name:</label>
        <input type="text" id="username" name="username" value="<?php echo $username; ?>" disabled>
        <label for="gender">gender:</label>
        <select id="gender" name="gender">
          <option value="secret" <?php if ($gender == 'secret')
            echo 'selected'; ?>>bukechade</option>
          <option value="male" <?php if ($gender == 'M')
            echo 'selected'; ?>>male</option>
          <option value="female" <?php if ($gender == 'F')
            echo 'selected'; ?>>female</option>
          <option value="others" <?php if ($gender == 'O')
            echo 'selected'; ?>>others</option>
        </select>
        <label for="birthday">birthday:</label>
        <input type="date" id="birthday" name="birthday" value="<?php echo $birthday; ?>">
        <label for="phone">phonenumber:</label>
        <input type="text" id="phone" name="phone" value="<?php echo $phone; ?>">

        <label for="motto">motto:</label>
        <input type="text" id="motto" name="motto" value="<?php echo $motto; ?>">
        <br>
        <input type="submit" value="save">
      </form>
      <button class="return-button" onclick="redirectToChooseMovie()">return</button>
    </div>
  </div>
  </div>

  <script>
    function redirectToChooseMovie() {
      var userid = "<?php echo $userid; ?>";
      window.location.href = "choosemovie.php?userid=" + userid;
    }
  </script>
</body>

</html>