<!DOCTYPE html>
<html>

<head>
    <title>look what is showing!</title>
    <link href="https://fonts.googleapis.com/css2?family=Zhi+Mang+Xing&display=swap" rel="stylesheet">

    <style>
        .h1-style {
            text-align: center;
            font-family: 'Zhi Mang Xing', cursive;
            font-size: 60px;
            font-weight: bold;
            color: #333;
            margin: 0;
            padding: 20px;
        }

        .container {
            padding: 10px;
            margin: 10px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        table {
            border-collapse: collapse;
            width: 100%;
        }

        th,
        td {
            text-align: left;
            padding: 8px;
        }

        th {
            background-color: #2097d7;
            
            color: white;
        }

        tr:nth-child(even) {
            background-color: #f2f2f2;
        }

        input[type=text] {
            width: 100%;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
            box-sizing: border-box;
            font-size: 16px;
        }

        form input[type="date"] {
            width: 100%;
            height: 40px;
            font-size: 16px;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
            box-sizing: border-box;
            font-size: 16px;
            font-family: Arial, sans-serif;
            margin-bottom: 10px;
        }

        label {
            display: inline-block;
            margin-bottom: 10px;
            margin-top: 10px;
            text-align: right;
            font-size: 16px;
            font-weight: bold;
        }

        .filter-button {
            padding: 6px;
            border: none;
            border-radius: 4px;
            background-color: #2097d7;

            color: white;
            margin-left: 10px;
            display: inline-block;
        }

        .new-button {
            padding: 6px;
            border: none;
            border-radius: 4px;
            background-color: #2097d7;

            color: white;
            display: inline-block;
        }
        .new-button:hover{
            background-color: #EEA23A;
        }

        button {
            padding: 10px;
            margin-right: 10px;
            border: none;
            border-radius: 5px;
            box-shadow: 0px 0px 5px grey;
            font-size: 16px;
            font-weight: bold;
            cursor: pointer;
        }
        button:hover{
            background-color: #EEA23A;
        }

        #submit {
            background-color: #2097d7;

            color: white;
        }
        #submit:hover{
            background-color: #EEA23A;
        }

        #close {
            background-color: #2097d7;

            color: white;
        }
        #close:hover{
            background-color: #EEA23A;
        }

        select {
            padding: 6px;
            margin-right: 10px;
            border: none;
            border-radius: 5px;
            box-shadow: 0px 0px 5px grey;
            font-size: 16px;
            font-weight: bold;
            cursor: pointer;
            display: inline-block;
            background-color: #2097d7;

            color: white;
        }
        select:hover{
            background-color: #EEA23A;
        }
    </style>
    <h1 class="h1-style">look what is showing!</h1>
</head>

<body>
    <div class="container">
        <form method="get">
            <input type="text" name="name" style="width:50%;" placeholder="search the movie name...">
            <button type="submit" class="filter-button">search for..</button>
        </form>
        <button id="showPopup" onclick="redirectToTicket('<?php echo $_GET['userid']; ?>')"
            class="new-button">myorder</button>
        <button id="showPopup" onclick="redirectToCenter('<?php echo $_GET['userid']; ?>')"
            class="new-button">my home</button>
        <button id="showPopup" onclick="redirectToIndex()" class="new-button">log out</button>

        <script>
            function redirectToIndex() {
                window.location.href = "index.html";
            }
            function redirectToCenter(userid) {
                window.location.href = "information.php?userid=" + userid;
            }
            function redirectToTicket(userid) {
                window.location.href = "myticket.php?userid=" + userid;
            }
        </script>

    </div>
    <table>
        <thead>
            <tr>
                <th>movie name</th>
                <th>duration</th>
                <th>country</th>
                <th>language</th>
                <th>release time</th>
                <th>showing time</th>
                <th>action</th>
            </tr>
        </thead>
        <tbody>
            <?php
            // 连接数据库
            include("connect.php");

            // 查询电影信息
            $sql = "SELECT * FROM movie WHERE 1=1";

            if (isset($_GET['name'])) {
                $name = $_GET['name'];
                $sql .= " AND moviename LIKE '%$name%'";
            }

            $result = $conn->query($sql);
            
            // 输出表格
            if ($result->num_rows > 0) {
                while ($row = $result->fetch_assoc()) {
                    echo "<tr>";
                    echo "<td>" . $row["MovieName"] . "</td>";
                    echo "<td>" . $row["Duration"] . "</td>";
                    echo "<td>" . $row["Country"] . "</td>";
                    echo "<td>" . $row["Language"] . "</td>";
                    //echo "<td>" . $row["Type"] . "</td>";
                    echo "<td>" . $row["ReleaseTime"] . "</td>";
                    echo "<td>
                    <button class='filter-button' onclick=\"chooseshowing('" . $row["MovieID"] . "', '" . $_GET["userid"] . "','".$row['MovieName']."')\">search for screening time</button>
                    </td>";
                    echo "</tr>";
                }
            } else {
                echo "<tr><td colspan='6'>0 result</td></tr>";
            }

            // 断开数据库连接
            mysqli_close($conn);
            ?>

        </tbody>
    </table>
    <script>
        function chooseshowing(movieId, userId,moviename) {
            window.location.href = "chooseshowing.php?movieid=" + movieId + "&userid=" + userId+"&moviename"+moviename;
        }
    </script>

    <script>
        const searchInput = document.querySelector('input[type="text"]');
        const searchButton = document.querySelector('button[type="submit"]');
        const form = document.createElement('form');
        form.style.display = 'inline-block';
        form.style.marginLeft = '1em';

        searchInput.parentNode.insertBefore(form, searchInput.nextSibling);
        form.appendChild(searchInput);
        form.appendChild(searchButton);

        form.addEventListener('submit', function (event) {
            event.preventDefault();

            const searchValue = searchInput.value.trim();
            const currentUrl = new URL(window.location.href);

            currentUrl.searchParams.set('name', searchValue);
            currentUrl.searchParams.delete('type');

            window.location.href = currentUrl.toString();
        });
        function showPopup() {
            var myForm = document.getElementById("myForm");
            myForm.style.display = "block";
        }
        function closeForm() {
            var myForm = document.getElementById("myForm");
            myForm.style.display = "none";
        }

    </script>
</body>

</html>