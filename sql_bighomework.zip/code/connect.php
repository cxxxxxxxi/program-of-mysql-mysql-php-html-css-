<?php
$host = 'localhost:3306'; // MySQL 服务器地址
$username = 'root'; // 用户名
$password = ''; // 密码
$database = 'exercise'; // 数据库名称

// 创建数据库连接
$conn = mysqli_connect($host, $username, $password, $database);

if (!$conn) {
	die("can't connect to the sql：" . mysqli_error($conn));
}
//选择字符集
mysqli_set_charset($conn, 'utf8');
/*
$insert_sql="insert into user() values('N1011', 'jakd_wefite', 'eefsfsr', '8882351111')";
if($conn->Query($insert_sql)===TRUE){
	echo "chenggong";
}*/
//$conn->close();
?>