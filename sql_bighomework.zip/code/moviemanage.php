<!DOCTYPE html>
<html>

<head>
    <title>manage movies</title>
    <style>
        .container {
            background-color: #2097d7;
            border: 1px solid #ccc;
            padding: 10px;
            margin: 10px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        table {
            border-collapse: collapse;
            width: 100%;
        }

        th,
        td {
            text-align: left;
            padding: 8px;
        }

        th {
            background-color: #2097d7;
            color: white;
        }

        tr:nth-child(even) {
            background-color: #2097d7;
        }

        input[type=text] {
            width: 100%;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
            box-sizing: border-box;
            font-size: 16px;
        }

        form input[type="date"] {
            width: 100%;
            height: 40px;
            font-size: 16px;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
            box-sizing: border-box;
            font-size: 16px;
            font-family: Arial, sans-serif;
            margin-bottom: 10px;
        }

        label {
            display: inline-block;
            margin-bottom: 10px;
            margin-top: 10px;
            text-align: right;
            font-size: 16px;
            font-weight: bold;
        }

        .filter-button {
            padding: 6px;
            border: none;
            border-radius: 4px;
            background-color: #a67edb;
            color: white;
            margin-left: 10px;
            display: inline-block;
        }
        .filter-button:hover {
            background-color: #EEA23A;
            color: #fff;
            transform: scale(1.05);
        }

        .new-button {
            padding: 6px;
            border: none;
            border-radius: 4px;
            background-color: #a67edb;
            color: white;
            display: inline-block;
        }
        .new-button:hover {
            background-color: #705A70;
            color: #fff;
            transform: scale(1.05);
        }

        button {
            padding: 10px;
            margin-right: 10px;
            border: none;
            border-radius: 5px;
            box-shadow: 0px 0px 5px grey;
            font-size: 16px;
            font-weight: bold;
            cursor: pointer;
        }

        #submit {
            background-color: #2097d7;
            color: white;
        }
        #submit:hover {
            background-color: #EEA23A;
            color: #fff;
            transform: scale(1.05);
        }

        #close {
            background-color: #2097d7;
            color: white;
        }
        #close:hover {
            background-color: #EEA23A;
            color: #fff;
            transform: scale(1.05);
        }

        select {
            padding: 6px;
            margin-right: 10px;
            border: none;
            border-radius: 5px;
            box-shadow: 0px 0px 5px grey;
            font-size: 16px;
            font-weight: bold;
            cursor: pointer;
            display: inline-block;
            background-color: #EEA23A;
            color: white;
        }
    </style>
</head>

<body>
    <div class="container">
        <form method="get">
            <input type="text" name="name" style="width:50%;" placeholder="search for movie's neme...">
            <button type="submit" class="filter-button">search for...</button>
        </form>

        <button id="showPopup" onclick="showPopup()" class="new-button">add new movies</button>

        <form id="myForm" method="post" action='updatemovie.php'
            style="border-radius: 10px;text-align: center; box-shadow: 0px 0px 10px grey;display:none; position: fixed; top: 50%; left: 50%; transform: translate(-50%, -50%); background-color: white; padding: 20px; ">
            <label for="movieid">movie  ID</label>
            <input type="text" id="movieid" name="movieid"><br>
            <label for="moviename">movie name</label>
            <input type="text" id="moviename" name="moviename"><br>
            <label for="duration">duration</label>
            <input type="text" id="duration" name="duration"><br>
            <label for="country">country</label>
            <input type="text" id="country" name="country"><br>
            <label for="language">language</label>
            <input type="text" id="language" name="language"><br>
            <label for="releasetime">releasetime</label>
            <input type="date" id="releasetime" name="releasetime"><br>
            <button type="submit">add more...</button>
            <button type="button" onclick="closeForm()">close</button>
        </form>

        <button id="showPopup" onclick="redirectToShowingManage()" class="new-button">Film venue management</button>
        <button id="showPopup" onclick="redirectToTicket()" class="new-button">order management</button>
        <button id="showPopup" onclick="redirectToIndex()" class="new-button">return homepage</button>

        <script>
            function redirectToShowingManage() {
                window.location.href = "showingmanage.php";
            }
            function redirectToTicket() {
                window.location.href = "ticketmanage.php";
            }
            function redirectToIndex() {
                window.location.href = "index.html";
            }
        </script>
    </div>

    <table>
        <thead>
            <tr>
                <th>movie ID</th>
                <th>movie name</th>
                <th>duration</th>
                <th>country</th>
                <th>language</th>
                <th>movie type</th>
                <th>release time</th>
                <th>frequency</th>
                <th>action</th>
            </tr>
        </thead>
        <tbody>
            <?php
            // 连接数据库
            include("connect.php");

            // 查询电影信息
            $sql = "SELECT m.movieid, m.MovieName, m.Duration, m.Country, m.Language, GROUP_CONCAT(DISTINCT ht.MovieTypeName) AS Types, m.ReleaseTime, COUNT(distinct s.showingid) AS ShowingCount
            FROM Movie m
            LEFT JOIN (SELECT DISTINCT MovieID, MovieTypeName FROM havetype) ht ON m.MovieID = ht.MovieID
            LEFT JOIN showing s ON m.MovieID = s.MovieID
                WHERE 1=1";

            if (isset($_GET['name'])) {
                $name = $_GET['name'];
                $sql .= " AND m.MovieName LIKE '%$name%'";
            }

            $sql .= " GROUP BY m.MovieID";

            $result = $conn->query($sql);

            // 输出表格
            if ($result->num_rows > 0) {
                while ($row = $result->fetch_assoc()) {
                    echo "<tr>";
                    echo "<td>" . $row["movieid"] . "</td>";
                    echo "<td>" . $row["MovieName"] . "</td>";
                    echo "<td>" . $row["Duration"] . "</td>";
                    echo "<td>" . $row["Country"] . "</td>";
                    echo "<td>" . $row["Language"] . "</td>";
                    echo "<td>" . $row["Types"] . "</td>";
                    echo "<td>" . $row["ReleaseTime"] . "</td>";
                    echo "<td>" . $row["ShowingCount"] . "</td>";
                    echo "<td>
                    <button class='filter-button' onclick=\"window.location.href='updatemovieinfo.php?movieid=" . $row['movieid'] . "'\">revise</button>

                    <button class='filter-button' onclick=\"deleteMovie('" . $row['movieid'] . "')\">delete</button>
                    </td>";
                    echo "</tr>";
                }
            } else {
                echo "<tr><td colspan='6'>0 result</td></tr>";
            }

            // 断开数据库连接
            mysqli_close($conn);
            ?>

        </tbody>
    </table>
    <script>
        function deleteMovie(movieId) {
            if (confirm("Are you sure to delete this movie？")) {
                window.location.href = "deletemovie.php?movieid=" + movieId;
            }
        }
    </script>

    <script>
        const searchInput = document.querySelector('input[type="text"]');
        const searchButton = document.querySelector('button[type="submit"]');
        const form = document.createElement('form');
        form.style.display = 'inline-block';
        form.style.marginLeft = '1em';

        searchInput.parentNode.insertBefore(form, searchInput.nextSibling);
        form.appendChild(searchInput);
        form.appendChild(searchButton);

        form.addEventListener('submit', function (event) {
            event.preventDefault();

            const searchValue = searchInput.value.trim();
            const currentUrl = new URL(window.location.href);

            currentUrl.searchParams.set('name', searchValue);
            currentUrl.searchParams.delete('type');

            window.location.href = currentUrl.toString();
        });
        function showPopup() {
            var myForm = document.getElementById("myForm");
            myForm.style.display = "block";
        }
        function closeForm() {
            var myForm = document.getElementById("myForm");
            myForm.style.display = "none";
        }

    </script>
</body>

</html>